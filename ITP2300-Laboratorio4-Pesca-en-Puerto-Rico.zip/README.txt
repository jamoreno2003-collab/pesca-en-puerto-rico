PESCA EN PUERTO RICO — LABORATORIO 4
Proyecto educativo de Jorge Moreno

ARCHIVOS
- index.html: página de inicio
- guia.html: guía y tabla informativa
- contacto.html: formulario de demostración
- css/style.css: diseño adaptable
- images/logo.svg: logotipo

PUBLICAR CON GITHUB PAGES
1. Entra a https://github.com e inicia sesión.
2. Crea un repositorio nuevo. Puedes llamarlo pesca-en-puerto-rico.
3. Sube todos los archivos y carpetas de este proyecto; no subas solamente el ZIP.
4. En el repositorio abre Settings > Pages.
5. En Build and deployment, selecciona Deploy from a branch.
6. Selecciona la rama main y la carpeta /(root), y guarda.
7. Espera a que GitHub Pages publique el sitio. El enlace suele tener este formato:
   https://TU-USUARIO.github.io/pesca-en-puerto-rico/
8. Abre el enlace y verifica Inicio, Guía de pesca y Contacto.
9. Entrega al profesor ese enlace publicado, no el enlace del repositorio.

NOTAS
- El formulario de contacto es demostrativo: valida los campos, pero no envía mensajes a un servidor.
- La imagen principal se carga desde Unsplash, por lo que requiere conexión a internet.
- Verifica las reglas locales y las fuentes oficiales antes de usar información sobre pesca.
